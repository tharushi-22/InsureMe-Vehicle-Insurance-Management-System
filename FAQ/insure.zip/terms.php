<!--Amarasekara D.I.-->
<!DOCTYPE html>
<head>
	<link rel="stylesheet" type="text/css" href="fff.css">
  <?php require("Header.php"); ?>
  <link href="privacy.css" rel="stylesheet">
</head>

<body> 
<br>
  <div class="privacy-policy">
    <h1>Terms and Conditions</h1>
        <div class="section">
            <h2>Introduction</h2>
            <p>Welcome to our website. If you continue to browse and use this website, you are agreeing to comply with and be bound by the following terms and conditions of use.</p>
        </div>
        <div class="section">
            <h2>Use of Website</h2>
            <p>The content of the pages of this website is for your general information and use only. It is subject to change without notice.</p>
        </div>
        <div class="section">
            <h2>Disclaimer</h2>
            <p>The information contained in this website is for general information purposes only. The information is provided by us and while we endeavor to keep the information up to date and correct, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website or the information, products, services, or related graphics contained on the website for any purpose.</p>
        </div>
        <div class="section">
            <h2>Limitation of Liability</h2>
            <p>In no event will we be liable for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data or profits arising out of, or in connection with, the use of this website.</p>
        </div>
        <div class="section">
            <h2>Changes to Terms and Conditions</h2>
            <p>We reserve the right to modify these terms and conditions at any time, so please review it frequently. Changes and clarifications will take effect immediately upon their posting on the website.</p>
        </div>
  </div>
<br>
<body>
        <footer class="footer">
            <div class="container">
             <div class="row">
               <div class="footer-col">
                   <h4>Insure Me</h4>
                   <img src="Logo_updt.png">
                   <ul class="info">
                     <li>
                       <span><i class="fa fa-map-marker" aria-hidden="true"></i>
                       </span>
                       <span>456,Park Street,Colombo 03.<br>Sri Lanka</span>
                     </li>
                     <li>
                       <span><i class="fa fa-phone" aria-hidden="true"></i></span>
                       <p><a href="tel:+94112548654">+94112548654</a></p>
                       <p><a href="tel:+94112548700">+94112548700</a></p>
                     </li>
                     <li>
                       <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
                       <p><a href="mailto:bidzone@gmail.com">insureme@gmail.com</a></p>
                     </li>
                   </ul>
               </div>
               <div class="footer-col">
                 <h4>Company</h4>
                 <ul>
                   <li><a href="#">Home</a></li>
                   <li><a href="#">About Us</a></li>
                   <li><a href="#">Contact Us</a></li>
				   <li><a href="PrivacyPolicy.php">Privacy Policy</a></li>
                 </ul>
               </div>
               <div class="footer-col">
                 <h4>services</h4>
                 <ul>
                   <li><a href="#">Help Us</a></li>
                 </ul>
               </div>
               <div class="footer-col">
                 <h4>follow us</h4>
                 <div class="social-links">
                   <a href="#"><i class="fab fa-facebook-f"></i></a>
                   <a href="#"><i class="fab fa-twitter"></i></a>
                   <a href="#"><i class="fab fa-instagram"></i></a>
                   <a href="#"><i class="fab fa-linkedin-in"></i></a>
                 </div>
               </div>
             </div>
            </div>
        </footer>
</body>
</html>