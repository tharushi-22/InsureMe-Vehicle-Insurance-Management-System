<!--Amarasekara D.I-->
<!DOCTYPE html>
<head>
<link rel="stylesheet" type="text/css" href="footer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>

<br>
        <footer class="footer">
            <div class="container">
             <div class="row">
               <div class="footer-col">
                   <h4>Insure Me</h4>
                   <img src="Logo_updt.png">
                   <ul class="info">
                     <li>
                       <span><i class="fa fa-map-marker" aria-hidden="true"></i>
                       </span>
                       <span>456,Park Street,Colombo 03.<br>Sri Lanka</span>
                     </li>
                     <li>
                       <span><i class="fa fa-phone" aria-hidden="true"></i></span>
                       <p><a href="tel:+94112548654">+94112548654</a></p>
                       <p><a href="tel:+94112548700">+94112548700</a></p>
                     </li>
                     <li>
                       <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
                       <p><a href="mailto:bidzone@gmail.com">insureme@gmail.com</a></p>
                     </li>
                   </ul>
               </div>
               <div class="footer-col">
                 <h4>Company</h4>
                 <ul>
                   <li><a href="#">Home</a></li>
                   <li><a href="#">About Us</a></li>
                   <li><a href="#">Contact Us</a></li>
				   <li><a href="PrivacyPolicy.php">Privacy Policy</a></li>
                 </ul>
               </div>
               <div class="footer-col">
                 <h4>services</h4>
                 <ul>
                   <li><a href="#">Help Us</a></li>
                 </ul>
               </div>
               <div class="footer-col">
                 <h4>follow us</h4>
                 <div class="social-links">
                   <a href="#"><i class="fab fa-facebook-f"></i></a>
                   <a href="#"><i class="fab fa-twitter"></i></a>
                   <a href="#"><i class="fab fa-instagram"></i></a>
                   <a href="#"><i class="fab fa-linkedin-in"></i></a>
                 </div>
               </div>
             </div>
            </div>
        </footer>
</body>
</html>