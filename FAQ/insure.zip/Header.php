<!DOCTYPE html>
<head>
	<link rel="stylesheet" type="text/css" href="header.css">
</head>

<body> 

<header class="nav">
    <a href="#"> <img src="Logo_updt.png" width="119px" height="119px" style="border-radius: 20%;"></a>
    
    <div class="links">
        <a href="#">Home</a>
        <a href="#">Insurance Policies</a>
        <a href="#">About Us</a>
        <a href="#">Contact us</a>
		<a href="#">FAQ</a>
		<a href="#">Register</a>
		<a href="#">Login</a>
    </div>
	
</header>

</body>
</html>